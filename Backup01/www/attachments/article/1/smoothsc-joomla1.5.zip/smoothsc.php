<?php
/**
* @version		$Id: smoothsc.php rel. 0.8  28-06-2008  $
* @package		Smooth-Scroll for Joomla!
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Author: Riccardo Budini |  http://www.provisum-illumina.com
* Smooth-Scroll for Joomla is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* 28-06-2008  rel. 0.6 for Joomla! 1.5.x
*/


// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import library dependencies
jimport('joomla.event.plugin');

/**
* Plugin that loads module positions within content
*/
class plgContentsmoothsc extends JPlugin
{
   /**
    * Constructor
    *
    * For php4 compatability we must not use the __constructor as a constructor for
    * plugins because func_get_args ( void ) returns a copy of all passed arguments
    * NOT references.  This causes problems with cross-referencing necessary for the
    * observer design pattern.
    */
    function plgContentsmoothsc ( &$subject, $config)
	{
		parent::__construct( $subject, $config, $params );
			  
	}
    /**
    * Plugin method with the same name as the event will be called automatically.
    */
    function onPrepareContent( &$row, &$params)
    {
       
		$document =& JFactory::getDocument();
		JHTML::_( 'behavior.mootools' );
				
		//	Add Javascript
		$document->addScript( JURI::base() .'plugins/content/smoothsc/smoothsc.js');
		
		
	
// Replace the Smooth-Scroll mostag	
		$row->text = str_replace( "{smooth-scroll-top}", "<a style=\"".$this->params->get('Style')."\" href=\"#".$this->params->get('Div-Top-Name')."\" rel=\"nofollow\" name=\"".$this->params->get('Div-Top-Name')."\">
<img alt=\"top-icon\" src=\"plugins/content/smoothsc/icons/".$this->params->get('IconType')."\" align=\"".$this->params->get('AlignIcon')."\" vspace=\"".$this->params->get('Vspace')."\" hspace=\"".$this->params->get('Hspace')."\">".$this->params->get('Text')."</a>", $row->text );

	}

}
?>
